module.exports = {
    secretKey : '1023ldde',
    option : {
        algorithm : 'HS256',
        expiresIn : '1h',
        issuer : 'issuer'
    }
}